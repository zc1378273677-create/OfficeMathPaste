"""Local LaTeX/MathML to Office Math. No network access at runtime."""
from __future__ import annotations
import html as html_std
import os
import re
import uuid
from copy import deepcopy
from pathlib import Path
from lxml import etree, html
from latex2mathml.converter import convert

SKIP = {'pre', 'code', 'script', 'style', 'textarea'}
BLOCKS = {'p','div','section','article','blockquote','li','h1','h2','h3','h4','h5','h6'}
MATH_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'

def find_xsl():
    """Locate the MathML-to-OMML transform across MSI and Click-to-Run Office."""
    candidates = []
    seen = set()

    def add(path):
        if not path:
            return
        path = Path(path).expanduser()
        key = os.path.normcase(str(path))
        if key not in seen:
            seen.add(key)
            candidates.append(path)

    # An explicit override is useful for portable Office and enterprise images.
    add(os.environ.get('OFFICE_MATH_XSL'))
    roots = []
    try:
        import winreg
        views = (0, winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY)
        for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
            for view in views:
                access = winreg.KEY_READ | view
                try:
                    key_path = r'SOFTWARE\Microsoft\Office\ClickToRun\Configuration'
                    with winreg.OpenKey(hive, key_path, 0, access) as key:
                        install = winreg.QueryValueEx(key, 'InstallationPath')[0]
                    for version in ('Office16', 'Office15', 'Office14', 'Office12'):
                        roots.extend((Path(install) / 'root' / version,
                                      Path(install) / version))
                except OSError:
                    pass
                for version in ('16.0', '15.0', '14.0', '12.0'):
                    for app in ('Word', 'Common'):
                        try:
                            key_path = r'SOFTWARE\Microsoft\Office\{}\{}\InstallRoot'.format(version, app)
                            with winreg.OpenKey(hive, key_path, 0, access) as key:
                                roots.append(Path(winreg.QueryValueEx(key, 'Path')[0]))
                        except OSError:
                            pass
    except ImportError:
        pass

    bases = {os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)'),
             'C:/Program Files/Microsoft Office', 'C:/Program Files (x86)/Microsoft Office'}
    for base in bases:
        if not base:
            continue
        base = Path(base)
        # Accept either the Program Files directory or the Microsoft Office directory.
        if base.name.lower() != 'microsoft office':
            base = base / 'Microsoft Office'
        for version in ('Office16', 'Office15', 'Office14', 'Office12'):
            roots.extend((base / 'root' / version, base / version))
    for root in roots:
        add(root / 'MML2OMML.XSL')
    for path in candidates:
        if path.is_file():
            return path
    raise FileNotFoundError(
        'Office MML2OMML.XSL was not found. Install desktop Word, or set '
        'OFFICE_MATH_XSL to the full path of MML2OMML.XSL.')

def fragment(raw):
    if isinstance(raw, str):
        raw = raw.encode('utf-8')
    # CF_HTML offsets are bytes, not Unicode character offsets.
    start = re.search(br'StartFragment:(\d+)', raw[:1500])
    end = re.search(br'EndFragment:(\d+)', raw[:1500])
    if start and end and 0 <= int(start[1]) < int(end[1]) <= len(raw):
        raw = raw[int(start[1]):int(end[1])]
    else:
        start_html = re.search(br'StartHTML:(\d+)', raw[:1500])
        if start_html and 0 <= int(start_html[1]) < len(raw):
            raw = raw[int(start_html[1]):]
    return raw.rstrip(b'\0').decode('utf-8', errors='replace')

def escaped(text, index):
    n = 0
    index -= 1
    while index >= 0 and text[index] == '\\':
        n += 1
        index -= 1
    return n % 2 == 1

def formulas(text):
    """Yield complete delimited ranges; leave malformed/currency text alone."""
    protected = bytearray(len(text))
    for match in re.finditer(r'```[\s\S]*?```|~~~[\s\S]*?~~~|`+[^`\n]*`+|https?://[^\s<>]+', text):
        protected[match.start():match.end()] = b'\1' * (match.end()-match.start())
    i = 0
    while i < len(text):
        if protected[i] or escaped(text, i):
            i += 1
            continue
        opener = next((s for s in ('\\[', '\\(', '$$', '$') if text.startswith(s, i)), None)
        if not opener:
            i += 1
            continue
        if opener.startswith('$') and (text[i-1:i] == '$' or text[i+len(opener):i+len(opener)+1] == '$'):
            i += len(opener)
            continue
        if opener == '$' and (i+1 == len(text) or text[i+1].isspace()):
            i += 1
            continue
        closer = {'\\[':'\\]', '\\(':'\\)', '$$':'$$', '$':'$'}[opener]
        display = opener in ('\\[', '$$')
        j = i + len(opener)
        found = False
        while j < len(text):
            if protected[j] or text[j] == '\0' or (not display and text[j] == '\n'):
                break
            if not escaped(text, j) and text.startswith(closer, j):
                if closer.startswith('$') and (text[j-1:j] == '$' or text[j+len(closer):j+len(closer)+1] == '$'):
                    j += len(closer)
                    continue
                body = text[i+len(opener):j]
                if body.strip() and (opener != '$' or not text[j-1].isspace()):
                    # Avoid interpreting two currency amounts as one equation.
                    if opener != '$' or not re.fullmatch(r'[\d.,\s]+', body):
                        yield i, j+len(closer), body.strip(), display
                i = j + len(closer)
                found = True
                break
            if not escaped(text,j) and opener.startswith('\\') and text.startswith(opener,j):
                break
            j += 1
        if not found:
            i += len(opener)

class Converter:
    def __init__(self):
        parser = etree.XMLParser(resolve_entities=False, no_network=True)
        self.transform = etree.XSLT(etree.parse(str(find_xsl()), parser))
        self.parser = parser

    @staticmethod
    def normalize_integrals(output):
        """Fill empty integral bases left by Office's MML2OMML stylesheet."""
        m = '{' + MATH_NS + '}'
        relations = ('=', '<', '>', '≤', '≥', '≠', '≈', '≡', '→')
        for nary in list(output.iter(m + 'nary')):
            symbol = nary.find(m + 'naryPr/' + m + 'chr')
            if symbol is None or symbol.get(m + 'val') not in '∫∬∭∮∯∰∱∲∳':
                continue
            base = nary.find(m + 'e')
            parent = nary.getparent()
            if base is None or len(base) or parent is None:
                continue
            following = list(parent)[parent.index(nary) + 1:]
            for item in following:
                # Do not absorb a following independent integral.
                if item.tag == m + 'nary' and len(base):
                    break
                text_node = item.find(m + 't') if item.tag == m + 'r' else None
                text = text_node.text if text_node is not None else ''
                positions = [text.find(mark) for mark in relations if mark in text]
                if positions:
                    stop = min(p for p in positions if p >= 0)
                    if stop:
                        before = deepcopy(item)
                        before.find(m + 't').text = text[:stop]
                        base.append(before)
                    text_node.text = text[stop:]
                    if not text_node.text:
                        parent.remove(item)
                    break
                parent.remove(item)
                base.append(item)

    def mathml(self, source):
        root = etree.fromstring(source.encode('utf-8'), self.parser)
        result = self.transform(root)
        output = result.getroot()
        if output is not None and etree.QName(output).localname == 'oMathPara':
            output = output.find('{'+MATH_NS+'}oMath')
        if output is None or etree.QName(output).localname != 'oMath':
            raise ValueError('MathML did not produce Office Math')
        self.normalize_integrals(output)
        return etree.tostring(output, encoding='unicode')

    def latex(self, tex, display=False):
        # latex2mathml does not parse aligned as a table. Its raw '&'
        # output is invalid XML. An array retains the equation rows and columns.
        tex = re.sub(r'\\begin\{aligned\}(?:\s*\[[tbc]\])?',
                     lambda match: r'\begin{array}{rl}', tex)
        tex = tex.replace(r'\end{aligned}', r'\end{array}')
        source = convert(tex, display='block' if display else 'inline')
        # latex2mathml emits an merror for some unsupported commands.
        if '<merror' in source:
            raise ValueError('Unsupported LaTeX')
        return self.mathml(source)

    def prepare(self, plain='', rich=None):
        """Return sanitized HTML with placeholders and native OMML replacements."""
        source = fragment(rich) if rich else '<div>' + html_std.escape(plain).replace('\r\n','\n').replace('\n','<br>') + '</div>'
        root = html.fragment_fromstring(source, create_parent='div')
        replacements = []
        nonce = 'OfficeMathPaste' + uuid.uuid4().hex

        def protect(omml, display):
            token = nonce + 'N' + str(len(replacements)) + 'End'
            replacements.append((token, omml, display))
            return token

        # Never import active content or remote document links into hidden Word.
        for node in list(root.iter()):
            if not isinstance(node.tag, str):
                continue
            tag = etree.QName(node).localname.lower()
            if tag in {'script','style','iframe','object','embed','link','meta','base'}:
                node.drop_tree()
                continue
            for attr in list(node.attrib):
                if attr.lower().startswith('on') or attr.lower() in ('src','srcset','background'):
                    del node.attrib[attr]

        for annotation in list(root.xpath('.//*[local-name()="annotation"]')):
            if annotation.get('encoding','').strip().lower() != 'application/x-tex':
                continue
            ancestors = list(annotation.iterancestors())
            if any(etree.QName(n).localname.lower() in SKIP for n in ancestors):
                continue
            container = next((n for n in ancestors if 'katex-display' in n.get('class','').split()), None)
            if container is None:
                container = next((n for n in ancestors if 'katex' in n.get('class','').split()), None)
            if container is None:
                container = next((n for n in ancestors if etree.QName(n).localname.lower() in {'math','mjx-container'}), None)
            if container is None or container.getparent() is None:
                continue
            display = ('katex-display' in container.get('class','').split() or container.get('display') in ('block','true'))
            try:
                token = protect(self.latex(''.join(annotation.itertext()).strip(), display), display)
            except Exception:
                continue
            marker = etree.Element('span')
            marker.text, marker.tail = token, container.tail
            container.getparent().replace(container, marker)

        # MathML without a TeX annotation can also be converted exactly. Replace
        # the whole renderer container, not just <math>: MathJax and KaTeX also
        # contain visible HTML which otherwise becomes a second, linear formula.
        for node in list(root.xpath('.//*[local-name()="math"]')):
            if node.getparent() is None:
                continue
            ancestors = list(node.iterancestors())
            if any(etree.QName(a).localname.lower() in SKIP for a in ancestors):
                continue
            container = next((n for n in ancestors
                              if etree.QName(n).localname.lower() == 'mjx-container'), None)
            if container is None:
                container = next((n for n in ancestors
                                  if 'katex-display' in n.get('class', '').split()), None)
            if container is None:
                container = next((n for n in ancestors if 'katex' in n.get('class', '').split()), None)
            target = container if container is not None else node
            if target.getparent() is None:
                continue
            display_values = {'block', 'true'}
            display = (node.get('display', '').lower() in display_values or
                       target.get('display', '').lower() in display_values or
                       'katex-display' in target.get('class', '').split())
            try:
                markup = etree.tostring(node, encoding='unicode', with_tail=False)
                if 'xmlns=' not in markup:
                    markup = markup.replace('<math', '<math xmlns="http://www.w3.org/1998/Math/MathML"', 1)
                token = protect(self.mathml(markup), display)
            except Exception:
                continue
            marker = etree.Element('span')
            marker.text, marker.tail = token, target.tail
            target.getparent().replace(target, marker)

        # Flatten only text content; formulas may cross bold/span boundaries.
        segments, pieces = [], []
        length = 0
        def append(value, node=None, attr=None):
            nonlocal length
            if value:
                if node is not None:
                    segments.append((node, attr, length, length+len(value)))
                pieces.append(value)
                length += len(value)
        def walk(node):
            tag = etree.QName(node).localname.lower() if isinstance(node.tag,str) else ''
            if tag in SKIP or tag in {'math','mjx-container'}:
                append('\0')
                return
            barrier = tag in {'td','th','tr','table','a'}
            block = tag in BLOCKS
            if barrier: append('\0')
            elif block or tag == 'br': append('\n')
            append(node.text, node, 'text')
            for child in node:
                walk(child)
                append(child.tail, child, 'tail')
            if barrier: append('\0')
            elif block: append('\n')
        walk(root)
        text = ''.join(pieces)
        for start, end, tex, display in reversed(list(formulas(text))):
            try:
                token = protect(self.latex(tex, display), display)
            except Exception:
                continue
            affected = [(n,a,f,t) for n,a,f,t in segments if t > start and f < end]
            for index, (node, attr, begin, finish) in enumerate(affected):
                old = getattr(node, attr) or ''
                left, right = max(start,begin)-begin, min(end,finish)-begin
                setattr(node, attr, old[:left] + (token if index == 0 else '') + old[right:])
        if not replacements:
            return None
        body = etree.tostring(root, encoding='unicode', method='html')
        return '<!doctype html><html><head><meta charset="utf-8"></head><body>' + body + '</body></html>', replacements
