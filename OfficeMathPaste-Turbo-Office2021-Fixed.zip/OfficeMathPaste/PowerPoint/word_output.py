import re
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import html, etree as E

W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
W = '{' + W_NS + '}'
M = '{' + M_NS + '}'
XML_SPACE = '{http://www.w3.org/XML/1998/namespace}space'


def write_docx(path, markup, items):
    equations = {key: (xml, display) for key, xml, display in items}
    pattern = re.compile('(' + '|'.join(map(re.escape, equations)) + ')')
    doc = E.Element(W + 'document', nsmap={'w': W_NS, 'm': M_NS, 'r': R_NS})
    body = E.SubElement(doc, W + 'body')
    para = None

    def paragraph(display=False):
        nonlocal para
        if para is None:
            para = E.SubElement(body, W + 'p')
            props = E.SubElement(para, W + 'pPr')
            # Fixed line spacing and the East Asian document grid can clip the
            # denominator of a fraction after InsertFile into an existing file.
            E.SubElement(props, W + 'snapToGrid').set(W + 'val', '0')
            spacing = E.SubElement(props, W + 'spacing')
            spacing.set(W + 'lineRule', 'atLeast' if display else 'auto')
            spacing.set(W + 'line', '480' if display else '240')
        return para

    def equation_from_xml(xml):
        equation = E.fromstring(xml.encode('utf-8'))
        # Explicit math fonts avoid symbol substitution in different Office builds.
        for run in equation.iter(M + 'r'):
            props = run.find(W + 'rPr')
            if props is None:
                props = E.Element(W + 'rPr')
                run.insert(0, props)
            fonts = props.find(W + 'rFonts')
            if fonts is None:
                fonts = E.Element(W + 'rFonts')
                props.insert(0, fonts)
            for attr in ('ascii', 'hAnsi', 'cs'):
                fonts.set(W + attr, 'Cambria Math')
        # Retain the original plug-in's compact summation behavior.
        for properties in equation.iter(M + 'naryPr'):
            symbol = properties.find(M + 'chr')
            grow = properties.find(M + 'grow')
            if symbol is not None and symbol.get(M + 'val') == '∑' and grow is not None:
                grow.set(M + 'val', '0')
        return equation

    def add_equation(key):
        nonlocal para
        xml, display = equations[key]
        equation = equation_from_xml(xml)
        if display:
            # Display math must be in oMathPara and in its own Word paragraph.
            # This also prevents Word from merging adjacent inline math zones.
            para = None
            math_para = E.SubElement(paragraph(display=True), M + 'oMathPara')
            math_para.append(equation)
            para = None
        else:
            paragraph().append(equation)

    def add(text, styles):
        if not text or (para is None and not text.strip()):
            return
        for part in pattern.split(text):
            if not part:
                continue
            if part in equations:
                add_equation(part)
            else:
                run = E.SubElement(paragraph(), W + 'r')
                if styles:
                    props = E.SubElement(run, W + 'rPr')
                    for style in sorted(styles):
                        E.SubElement(props, W + style)
                t = E.SubElement(run, W + 't')
                t.set(XML_SPACE, 'preserve')
                t.text = part

    def walk(node, styles):
        nonlocal para
        if not isinstance(node.tag, str):
            return
        block = node.tag in ('p', 'div', 'li', 'blockquote', 'h1', 'h2', 'h3', 'tr')
        if block:
            para = None
        if node.tag == 'br':
            E.SubElement(E.SubElement(paragraph(), W + 'r'), W + 'br')
        style = {'strong': 'b', 'b': 'b', 'em': 'i', 'i': 'i'}.get(node.tag)
        if style:
            styles = styles | {style}
        add(node.text, styles)
        for child in node:
            walk(child, styles)
            add(child.tail, styles)
        if block:
            para = None

    walk(html.document_fromstring(markup).find('body'), set())

    content_types = '''<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>
</Types>'''
    root_rels = '''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>'''
    document_rels = '''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>
</Relationships>'''
    styles_xml = '''<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults><w:rPrDefault><w:rPr>
<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="宋体" w:cs="Calibri"/>
<w:sz w:val="22"/><w:szCs w:val="22"/>
</w:rPr></w:rPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
</w:styles>'''
    settings_xml = '''<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">
<m:mathPr><m:mathFont m:val="Cambria Math"/><m:brkBin m:val="before"/>
<m:brkBinSub m:val="--"/><m:smallFrac m:val="0"/><m:dispDef/>
<m:lMargin m:val="0"/><m:rMargin m:val="0"/><m:defJc m:val="centerGroup"/>
<m:wrapIndent m:val="1440"/><m:intLim m:val="subSup"/><m:naryLim m:val="undOvr"/>
</m:mathPr><w:defaultTabStop w:val="420"/></w:settings>'''
    with ZipFile(path, 'w', ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', content_types)
        z.writestr('_rels/.rels', root_rels)
        z.writestr('word/_rels/document.xml.rels', document_rels)
        z.writestr('word/document.xml', E.tostring(doc, encoding='utf-8', xml_declaration=True))
        z.writestr('word/styles.xml', styles_xml)
        z.writestr('word/settings.xml', settings_xml)
