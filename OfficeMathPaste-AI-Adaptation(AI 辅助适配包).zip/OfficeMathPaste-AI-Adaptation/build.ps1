﻿param([string]$Compiler,[string]$OfficePia,[string]$ExtensibilityPia)
$ErrorActionPreference='Stop'
if(!$Compiler){$Compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'}
if(!$OfficePia){$OfficePia=Get-ChildItem "$env:WINDIR\assembly\GAC_MSIL\office" -Filter office.dll -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName}
if(!$ExtensibilityPia){$ExtensibilityPia=Get-ChildItem "$env:WINDIR\assembly\GAC\Extensibility" -Filter Extensibility.dll -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName}
foreach($file in @($Compiler,$OfficePia,$ExtensibilityPia)){if(!$file -or !(Test-Path -LiteralPath $file)){throw '缺少编译器或 Office PIA，请用脚本参数提供本机路径。'}}
foreach($name in @('Word','PowerPoint')){
 $dir=Join-Path $PSScriptRoot "build\$name"
 New-Item -ItemType Directory -Force $dir | Out-Null
 $dll=if($name -eq 'Word'){'MathPaste.dll'}else{'PowerPointMath.dll'}
 & $Compiler /nologo /target:library /platform:anycpu "/out:$dir\$dll" "/reference:$OfficePia" "/reference:$ExtensibilityPia" /reference:Microsoft.CSharp.dll /reference:System.Windows.Forms.dll "$PSScriptRoot\src\$name.cs" "$PSScriptRoot\src\Engine.cs"
 if($LASTEXITCODE){throw "$name 构建失败"}
 Write-Host "$name 构建成功：$dir\$dll"
}
Write-Host '仅构建完成；未安装，未修改 Office 注册。请继续执行实机验证。'
