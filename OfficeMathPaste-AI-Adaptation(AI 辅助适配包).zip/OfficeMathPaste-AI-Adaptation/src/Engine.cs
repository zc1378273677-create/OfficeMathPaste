using System;
using System.Diagnostics;
using System.IO;
using System.Text;

internal sealed class Engine : IDisposable {
 readonly string folder;
 Process worker;
 public Engine(string folder){this.folder=folder;}
 public void Start(){
  if(worker!=null && !worker.HasExited)return;
  Dispose();
  var info=new ProcessStartInfo(Path.Combine(folder,@"..\runtime\python.exe"),"-u \""+Path.Combine(folder,"convert.py")+"\""){
   UseShellExecute=false,CreateNoWindow=true,RedirectStandardInput=true,RedirectStandardOutput=true};
  worker=Process.Start(info);
 }
 public bool Convert(string path){
  for(int attempt=0;attempt<2;attempt++){
   try{
    Start();
    worker.StandardInput.WriteLine(System.Convert.ToBase64String(Encoding.UTF8.GetBytes(path)));
    worker.StandardInput.Flush();
    var reply=worker.StandardOutput.ReadLineAsync();
    if(!reply.Wait(5000) || reply.Result==null)throw new IOException();
    return reply.Result=="OK";
   }catch{Dispose();}
  }
  return false;
 }
 public void Dispose(){
  if(worker==null)return;
  try{worker.StandardInput.Close();if(!worker.WaitForExit(200))worker.Kill();}catch{}
  worker.Dispose();worker=null;
 }
}
