using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.Office.Core;
using Extensibility;

[ComVisible(true),Guid("FDE3BDA7-13DF-4C9A-B0EF-E33074544651"),ProgId("BatterOffice.MathPaste"),ClassInterface(ClassInterfaceType.AutoDispatch)]
public class MathPaste : IDTExtensibility2, IRibbonExtensibility {
 dynamic app; Engine engine;
 static string dir=Path.GetDirectoryName(typeof(MathPaste).Assembly.Location);
 public void OnConnection(object a,ext_ConnectMode mode,object addin,ref Array custom){app=a; engine=new Engine(dir);try{engine.Start();}catch{}}
 public void OnDisconnection(ext_DisconnectMode mode,ref Array custom){if(engine!=null)engine.Dispose();app=null;}
 public void OnAddInsUpdate(ref Array custom){}
 public void OnStartupComplete(ref Array custom){}
 public void OnBeginShutdown(ref Array custom){}
 public string GetCustomUI(string id){return "<customUI xmlns='http://schemas.microsoft.com/office/2009/07/customui'><commands><command idMso='Paste' onAction='PasteMath'/></commands></customUI>";}
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern uint RegisterClipboardFormat(string name);
 [DllImport("user32.dll")] static extern bool OpenClipboard(IntPtr owner);
 [DllImport("user32.dll")] static extern bool CloseClipboard();
 [DllImport("user32.dll")] static extern IntPtr GetClipboardData(uint format);
 [DllImport("kernel32.dll")] static extern IntPtr GlobalLock(IntPtr handle);
 [DllImport("kernel32.dll")] static extern bool GlobalUnlock(IntPtr handle);
 [DllImport("kernel32.dll")] static extern UIntPtr GlobalSize(IntPtr handle);
 static byte[] ReadHtml(){
  uint format=RegisterClipboardFormat("HTML Format");
  if(!OpenClipboard(IntPtr.Zero))return new byte[0];
  try{
   IntPtr handle=GetClipboardData(format);
   if(handle==IntPtr.Zero)return new byte[0];
   ulong size=GlobalSize(handle).ToUInt64();
   if(size==0 || size>32000000)return new byte[0];
   IntPtr memory=GlobalLock(handle);
   if(memory==IntPtr.Zero)return new byte[0];
   try{byte[] bytes=new byte[(int)size];Marshal.Copy(memory,bytes,0,bytes.Length);return bytes;}
   finally{GlobalUnlock(handle);}
  }finally{CloseClipboard();}
 } public void PasteMath(IRibbonControl control,ref bool cancelDefault){
 cancelDefault=false;
 try{
 var data=Clipboard.GetDataObject(); if(data==null || data.GetDataPresent(DataFormats.FileDrop))return;
 string text=data.GetData(DataFormats.UnicodeText) as string ?? "";
 byte[] rich=ReadHtml();
 if(text.IndexOfAny(new char[]{'\\','$'})<0 && rich.Length==0)return;
 string temp=Path.Combine(Path.GetTempPath(),Guid.NewGuid().ToString("N"));
 Directory.CreateDirectory(temp);
 try{
 File.WriteAllText(Path.Combine(temp,"text"),text); File.WriteAllBytes(Path.Combine(temp,"html"),rich);
 if(!engine.Convert(temp))return;
 app.Selection.InsertFile(Path.Combine(temp,"paste.docx"));cancelDefault=true; }finally{Directory.Delete(temp,true);}
 }catch(Exception e){Trace.WriteLine(e.GetType().Name);}
 }
}




