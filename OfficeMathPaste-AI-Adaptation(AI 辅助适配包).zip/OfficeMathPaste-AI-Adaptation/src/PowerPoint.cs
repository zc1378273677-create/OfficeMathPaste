using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.Office.Core;
using Extensibility;

[ComVisible(true),Guid("911F4DF1-270A-4458-A3C4-CDC04E8DA119"),ProgId("BatterOffice.PowerPointMath"),ClassInterface(ClassInterfaceType.AutoDispatch)]
public class PowerPointMath : IDTExtensibility2, IRibbonExtensibility {
 dynamic app; Engine engine;
 static string dir=Path.GetDirectoryName(typeof(PowerPointMath).Assembly.Location);
 delegate IntPtr MessageHook(int code, IntPtr mode, IntPtr message);
 [StructLayout(LayoutKind.Sequential)] struct Msg { public IntPtr hwnd; public uint msg; public UIntPtr key; public IntPtr flags; }
 [DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx(int kind,MessageHook cb,IntPtr module,uint thread);
 [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr hook);
 [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr hook,int code,IntPtr mode,IntPtr msg);
 [DllImport("user32.dll")] static extern short GetKeyState(int key);
 [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr hwnd,System.Text.StringBuilder name,int count);
 [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr hwnd,uint flags);
 static bool IsEditingWindow(IntPtr foreground,IntPtr receiver){
  if(foreground==IntPtr.Zero || GetAncestor(receiver,2)!=foreground)return false;
  var name=new System.Text.StringBuilder(128);
  GetClassName(foreground,name,name.Capacity);
  return name.ToString()=="PPTFrameClass";
 }
 MessageHook callback; IntPtr hook; Control dispatch; bool replay;
 static void Log(string msg){try{File.AppendAllText(Path.Combine(dir,"paste.log"),DateTime.Now.ToString("HH:mm:ss ")+msg+Environment.NewLine);}catch{}}
 void Attach(){
  dispatch=new Control();dispatch.CreateControl();var window=dispatch.Handle;
  callback=OnMessage;hook=SetWindowsHookEx(3,callback,IntPtr.Zero,GetCurrentThreadId());
  Log("Connected; keyboard hook="+(hook!=IntPtr.Zero));
 }
 void Detach(){if(hook!=IntPtr.Zero)UnhookWindowsHookEx(hook);if(dispatch!=null)dispatch.Dispose();}
 IntPtr OnMessage(int code,IntPtr mode,IntPtr address){
  try{if(code>=0 && mode.ToInt64()==1 && !replay){
   var msg=(Msg)Marshal.PtrToStructure(address,typeof(Msg));
   if(msg.msg==0x100 && msg.key.ToUInt64()==86 && GetKeyState(17)<0 && GetKeyState(16)>=0 && GetKeyState(18)>=0){
    IntPtr hwnd=GetForegroundWindow();
    if(IsEditingWindow(hwnd,msg.hwnd)){
     dispatch.BeginInvoke((Action)(()=>{
      if(GetForegroundWindow()!=hwnd)return;
      bool handled=false;
      try{PasteMath(null,ref handled);
       if(!handled){replay=true;app.CommandBars.ExecuteMso("Paste");}
      }catch(Exception e){Log("Keyboard paste "+e.GetType().Name+" "+e.HResult);}finally{replay=false;}
     }));
     Marshal.WriteInt32(address,IntPtr.Size,0);
    }
   }
  }}catch(Exception e){Log("Hook "+e.GetType().Name);}
  return CallNextHookEx(hook,code,mode,address);
 } public void OnConnection(object a,ext_ConnectMode mode,object addin,ref Array custom){app=a; engine=new Engine(dir);try{engine.Start();}catch{} Attach();}
 public void OnDisconnection(ext_DisconnectMode mode,ref Array custom){Detach();if(engine!=null)engine.Dispose();app=null;}
 public void OnAddInsUpdate(ref Array custom){}
 public void OnStartupComplete(ref Array custom){}
 public void OnBeginShutdown(ref Array custom){}
 public string GetCustomUI(string id){return "<customUI xmlns='http://schemas.microsoft.com/office/2009/07/customui'><commands><command idMso='Paste' onAction='PasteMath'/></commands></customUI>";}
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern uint RegisterClipboardFormat(string name);
 [DllImport("user32.dll")] static extern bool OpenClipboard(IntPtr owner);
 [DllImport("user32.dll")] static extern bool CloseClipboard();
 [DllImport("user32.dll")] static extern IntPtr GetClipboardData(uint format);
 [DllImport("kernel32.dll")] static extern IntPtr GlobalLock(IntPtr handle);
 [DllImport("kernel32.dll")] static extern bool GlobalUnlock(IntPtr handle);
 [DllImport("kernel32.dll")] static extern UIntPtr GlobalSize(IntPtr handle);
 static byte[] ReadHtml(){
  uint format=RegisterClipboardFormat("HTML Format");
  if(!OpenClipboard(IntPtr.Zero))return new byte[0];
  try{
   IntPtr handle=GetClipboardData(format);
   if(handle==IntPtr.Zero)return new byte[0];
   ulong size=GlobalSize(handle).ToUInt64();
   if(size==0 || size>32000000)return new byte[0];
   IntPtr memory=GlobalLock(handle);
   if(memory==IntPtr.Zero)return new byte[0];
   try{byte[] bytes=new byte[(int)size];Marshal.Copy(memory,bytes,0,bytes.Length);return bytes;}
   finally{GlobalUnlock(handle);}
  }finally{CloseClipboard();}
 } public void PasteMath(IRibbonControl control,ref bool cancelDefault){
 cancelDefault=false; if(replay)return; string stage="clipboard"; Log("Paste entered");
 try{
 var data=Clipboard.GetDataObject(); if(data==null || data.GetDataPresent(DataFormats.FileDrop))return;
 string text=data.GetData(DataFormats.UnicodeText) as string ?? "";
 byte[] rich=ReadHtml();
 if(text.IndexOfAny(new char[]{'\\','$'})<0 && rich.Length==0)return;
 string temp=Path.Combine(Path.GetTempPath(),Guid.NewGuid().ToString("N"));
 Directory.CreateDirectory(temp);
 try{
 File.WriteAllText(Path.Combine(temp,"text"),text); File.WriteAllBytes(Path.Combine(temp,"html"),rich);
 if(!engine.Convert(temp))return;
 string file=Path.Combine(temp,"paste.pptx"); if(!File.Exists(file)){Log("No recognized formula");return;}
 stage="target"; dynamic window=app.ActiveWindow;
 dynamic selection=window.Selection;
 dynamic target=null;
 if((int)selection.Type==3)target=selection.TextRange;
 dynamic slide=window.View.Slide;
 stage="open"; dynamic source=app.Presentations.Open(file,-1,0,0);
 try{
  dynamic shape=source.Slides.Item(1).Shapes.Item(1);
  stage="transfer"; if(target!=null){
   shape.TextFrame.TextRange.Copy();
   target.Paste();
  }else{
   shape.Copy();
   slide.Shapes.Paste();
  }
  cancelDefault=true; Log("Inserted");
 }finally{source.Close();} }finally{Directory.Delete(temp,true);}
 }catch(Exception e){Log(stage+" "+e.GetType().Name+" "+e.HResult);}
 }
}







