# OfficeMathPaste：AI 辅助适配包

将网页数学公式粘贴到 Word、PowerPoint，保留 Ctrl+C / Ctrl+V 的使用方式。此包供希望借助 GPT 等 AI 工具，为自己电脑上的 Office 调整程序的人使用。

**作者实际使用的版本：Microsoft Office 专业增强版 2016（Windows 桌面版）。** 用户曾验证 Word、PowerPoint 的公式粘贴；这不代表所有公式、所有构建号都已通过验证。最新“新文档另存为”流程只有模拟分支测试，仍需实机验证。

其他 Office 年份、Microsoft 365、32/64 位组合均须独立验证，不宣称通用兼容。当前方案依赖 Windows COM，不能直接用于 macOS 或 Office 网页版。Excel 仅在安装管理菜单的保存关闭功能范围内，不支持公式粘贴。

## 开始适配

1. 解压完整目录，把目录交给具备本地文件访问能力的 AI 编程工具。
2. 阅读 `docs/AI适配提示词.md`，补上你的 Office 产品名、版本、位数与错误现象，再交给 AI。
3. 按 `docs/适配指南.md` 定位问题。先修转换或加载的具体故障，再安装测试。
4. 按 `docs/验证清单.md` 验证；记录哪些项目实测通过、哪些尚未验证。

仅用网页版 GPT 时，可以提供源码、指南及脱敏样本；GPT 的文本建议不会自动修改电脑，需要你在本地应用并测试。

## 内容

- `OfficeMathPaste/`：最新运行包，含安装/还原菜单、Python 转换源码、嵌入式运行时及已编译 DLL。
- `src/Word.cs`、`src/PowerPoint.cs`：本工作区保存的 Turbo C# 加载项源码。
- `src/Engine.cs`：常驻 Python 进程与转换协议。
- `build.ps1`：使用本机 .NET Framework 编译器及 Office PIA 构建到 `build/`，不自动覆盖运行包。
- `AGENTS.md`：给 AI 编程工具的项目工作约束。

源码来自本项目工作区；本包未声明已完成 DLL 字节级可复现构建。需要修改 C# 时，请先构建，再对新 DLL 进行加载与粘贴验证。

## 运行与更新

运行 `OfficeMathPaste/install.cmd`：1 安装/更新，2 还原，3 退出，4 保存并关闭 Word/PowerPoint/Excel。安装范围是当前用户，通常无需管理员权限。安装或还原前必须完全关闭 Word、PowerPoint；选项 4 不会强制结束 Office 进程。

安装目录：`%LOCALAPPDATA%\BatterOffice\OfficeMathPastePackage\app`。首次安装备份在同级 `original`，不要删除，否则可能无法恢复原来的注册状态。

修改 Python 后更新运行包并重新安装；修改 C# 后先构建，将验证过的对应 DLL 放回运行包再安装。发布给他人前移除个人剪贴板内容、日志、文档和本机路径。

## 已知限制

- 复杂网页排版不保证完整保留；重点是文字与可编辑公式。
- 仅有 KaTeX 显示结构、没有源码时，恢复器只支持部分结构，不能保证恢复任意公式。
- PowerPoint 的粘贴路径、窗口识别、焦点和 COM 行为是版本适配重点。
- 保存关闭只连接可访问的运行实例；多实例、受保护视图或权限不同可能需要人工处理。
- 不自动推定本项目和第三方依赖的许可。公开发布前应由维护者明确项目许可证，并核对随包 Python、lxml、latex2mathml 等依赖的再分发许可及声明。
