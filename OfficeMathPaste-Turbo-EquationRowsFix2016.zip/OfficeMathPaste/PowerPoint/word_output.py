import re
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import html, etree as E

W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
def write_docx(path, markup, items):
    equations = {key: xml for key, xml, display in items}
    pattern = re.compile('(' + '|'.join(map(re.escape, equations)) + ')')
    doc = E.Element(W+'document', nsmap={'w':W[1:-1]})
    body = E.SubElement(doc,W+'body')
    para = None
    def paragraph():
        nonlocal para
        if para is None: para = E.SubElement(body,W+'p')
        return para
    def add(text, styles):
        nonlocal para
        if not text or (para is None and not text.strip()): return
        for part in pattern.split(text):
            if not part: continue
            if part in equations:
                equation = E.fromstring(equations[part].encode())
                math = '{http://schemas.openxmlformats.org/officeDocument/2006/math}'
                for properties in equation.iter(math+'naryPr'):
                    symbol = properties.find(math+'chr')
                    grow = properties.find(math+'grow')
                    if symbol is not None and symbol.get(math+'val') == '∑' and grow is not None:
                        grow.set(math+'val', '0')
                if equation.tag == 'equationRows':
                    for row in equation:
                        para = None
                        paragraph().append(row)
                    para = None
                else:
                    paragraph().append(equation)
            else:
                run = E.SubElement(paragraph(),W+'r')
                if styles:
                    props = E.SubElement(run,W+'rPr')
                    for style in sorted(styles): E.SubElement(props,W+style)
                t = E.SubElement(run,W+'t')
                t.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
                t.text = part
    def walk(node, styles):
        nonlocal para
        if not isinstance(node.tag,str): return
        block = node.tag in ('p','div','li','blockquote','h1','h2','h3','tr')
        if block: para = None
        if node.tag=='br':
            E.SubElement(E.SubElement(paragraph(),W+'r'),W+'br')
        style = {'strong':'b','b':'b','em':'i','i':'i'}.get(node.tag)
        if style: styles = styles | {style}
        add(node.text,styles)
        for child in node:
            walk(child,styles)
            add(child.tail,styles)
        if block: para = None
    walk(html.document_fromstring(markup).find('body'),set())
    with ZipFile(path,'w',ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        z.writestr('word/document.xml', E.tostring(doc,encoding='utf-8',xml_declaration=True))

