﻿param([ValidateSet('menu','install','restore')][string]$Action='menu')
$ErrorActionPreference='Stop'
$base=Join-Path $env:LOCALAPPDATA 'BatterOffice\OfficeMathPastePackage'
$backup=Join-Path $base 'original'
$payload=Join-Path $base 'app'
$views=if([Environment]::Is64BitOperatingSystem){@('32','64')}else{@('32')}
$apps=@(
 @{App='Word';Prog='BatterOffice.MathPaste';Id='{FDE3BDA7-13DF-4C9A-B0EF-E33074544651}';Class='MathPaste'},
 @{App='PowerPoint';Prog='BatterOffice.PowerPointMath';Id='{911F4DF1-270A-4458-A3C4-CDC04E8DA119}';Class='PowerPointMath'}
)
$keys=@(foreach($a in $apps){
 "HKCU\Software\Classes\CLSID\$($a.Id)"
 "HKCU\Software\Classes\$($a.Prog)"
 "HKCU\Software\Microsoft\Office\$($a.App)\Addins\$($a.Prog)"
})
$keys+='HKCU\Software\Microsoft\Office\PowerPoint\Addins\BatterOffice.MathPaste'
function OfficeClosed {
 if(Get-Process WINWORD,POWERPNT -ErrorAction SilentlyContinue){throw '请先保存文件并完全退出 Word 和 PowerPoint，然后重试。'}
}
function Snapshot {
 if(Test-Path "$backup\ready"){return}
 New-Item -ItemType Directory -Force $backup | Out-Null
 foreach($v in $views){for($i=0;$i -lt $keys.Count;$i++){
  $f="$backup\$v-$i.reg"
  reg.exe query $keys[$i] "/reg:$v" 2>$null | Out-Null
  if($LASTEXITCODE -eq 0){
   reg.exe export $keys[$i] $f /y "/reg:$v" | Out-Null
   if($LASTEXITCODE){throw '无法备份注册信息。'}
  }elseif(Test-Path $f){Remove-Item -LiteralPath $f}
 }}
 Set-Content "$backup\ready" '1'
}
function RestoreKeys {
 foreach($v in $views){for($i=0;$i -lt $keys.Count;$i++){
  reg.exe query $keys[$i] "/reg:$v" 2>$null | Out-Null
  if($LASTEXITCODE -eq 0){
   reg.exe delete $keys[$i] /f "/reg:$v" | Out-Null
   if($LASTEXITCODE){throw '还原注册信息失败。'}
  }
  $f="$backup\$v-$i.reg"
  if(Test-Path $f){reg.exe import $f "/reg:$v" | Out-Null; if($LASTEXITCODE){throw '导入备份失败。'}}
 }}
}
function Install {
 OfficeClosed
 foreach($a in $apps){
  $dll=Join-Path $PSScriptRoot "$($a.App)\$($a.Class).dll"
  [void][Reflection.AssemblyName]::GetAssemblyName($dll)
 }
 & "$PSScriptRoot\runtime\python.exe" -c "from math_core import Converter; Converter()"
 if($LASTEXITCODE){throw '公式转换组件检查失败。请确认本机安装了 Office 桌面版。'}
 Snapshot
 New-Item -Type Directory -Force $payload | Out-Null
 foreach($d in 'Word','PowerPoint','runtime'){Copy-Item -LiteralPath "$PSScriptRoot\$d" -Destination $payload -Recurse -Force}
 try{
 foreach($v in $views){
 $root=[Microsoft.Win32.RegistryKey]::OpenBaseKey('CurrentUser',"Registry$v")
 foreach($a in $apps){
 $dll=Join-Path $payload "$($a.App)\$($a.Class).dll"
 $cls="Software\Classes\CLSID\$($a.Id)"
 $k=$root.CreateSubKey("$cls\InprocServer32")
 $k.SetValue('','mscoree.dll');$k.SetValue('ThreadingModel','Both');$k.SetValue('Class',$a.Class)
 $k.SetValue('Assembly',[Reflection.AssemblyName]::GetAssemblyName($dll).FullName)
 $k.SetValue('RuntimeVersion','v4.0.30319');$k.SetValue('CodeBase',([uri]$dll).AbsoluteUri);$k.Close()
 $root.CreateSubKey("Software\Classes\$($a.Prog)\CLSID").SetValue('',$a.Id)
 $root.CreateSubKey("$cls\ProgId").SetValue('',$a.Prog)
 $k=$root.CreateSubKey("Software\Microsoft\Office\$($a.App)\Addins\$($a.Prog)")
 $k.SetValue('FriendlyName','数学公式粘贴');$k.SetValue('LoadBehavior',3,[Microsoft.Win32.RegistryValueKind]::DWord);$k.Close()
 }
 $k=$root.OpenSubKey('Software\Microsoft\Office\PowerPoint\Addins\BatterOffice.MathPaste',$true)
 if($k){$k.SetValue('LoadBehavior',0,[Microsoft.Win32.RegistryValueKind]::DWord);$k.Close()}
 $root.Close()
 }
 }catch{RestoreKeys;throw}
 Write-Host '安装完成。打开 Word 或 PowerPoint，使用 Ctrl+C、Ctrl+V 粘贴公式。'
}
function Restore {
 if(!(Test-Path "$backup\ready")){Write-Host '当前用户没有此安装包的还原记录。';return}
 OfficeClosed
 RestoreKeys
 $expected=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'BatterOffice\OfficeMathPastePackage'))
 foreach($dir in $payload,$backup){
  if((Test-Path $dir) -and ([IO.Path]::GetDirectoryName((Resolve-Path -LiteralPath $dir).Path) -eq $expected)){Remove-Item -LiteralPath $dir -Recurse -Force}
 }
 Write-Host '已恢复首次使用本包安装前的加载项注册状态。'
}
if($Action -ne 'menu'){if($Action -eq 'install'){Install}else{Restore};exit 0}

try { $Host.UI.RawUI.WindowTitle = 'Office 数学公式粘贴 · 安装管理' } catch {}
function ShowPage {
 Clear-Host
 Write-Host ''
 Write-Host '  Office 数学公式粘贴' -ForegroundColor Cyan
 Write-Host '  Word / PowerPoint · Turbo' -ForegroundColor DarkGray
 Write-Host '  ──────────────────────────────────────────────────' -ForegroundColor DarkGray
 Write-Host ''
 $installed=$null
 try{$installed=Test-Path "$payload\Word\MathPaste.dll"}catch{$installed=$null}
 if($null -eq $installed){Write-Host "  安装状态    暂时无法读取" -ForegroundColor Yellow}
 elseif($installed){Write-Host '  安装状态    已安装，可选择 1 更新' -ForegroundColor Green}
 else{Write-Host '  安装状态    尚未通过本安装包安装'}
 $running=@(Get-Process WINWORD,POWERPNT -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessName -Unique)
 if($running.Count){
  $names=($running | ForEach-Object {if($_ -eq 'WINWORD'){'Word'}else{'PowerPoint'}}) -join '、'
  Write-Host "  Office 状态 $names 正在运行" -ForegroundColor Yellow
  Write-Host '              请保存文档并关闭应用，再安装或还原。' -ForegroundColor DarkGray
 }else{Write-Host '  Office 状态 已关闭，可以操作' -ForegroundColor Green}
 Write-Host '  安装范围    当前 Windows 用户，无需管理员权限' -ForegroundColor DarkGray
 Write-Host ''
 Write-Host '  [1]  安装 / 更新'
 Write-Host '       启用 Word 和 PowerPoint 的 Ctrl+V 公式转换' -ForegroundColor DarkGray
 Write-Host ''
 Write-Host '  [2]  还原'
 Write-Host '       恢复首次使用本安装包之前的加载项状态' -ForegroundColor DarkGray
 Write-Host ''
 Write-Host '  [3]  退出'
 Write-Host ''
 Write-Host '  ──────────────────────────────────────────────────' -ForegroundColor DarkGray
}
function WaitReturn {
 Write-Host ''
 [void](Read-Host '  按 Enter 返回菜单')
}
while($true){
 ShowPage
 $choice=Read-Host '  请选择 1、2 或 3，按 Enter 确认'
 if($choice -eq '3'){break}
 if($choice -notin @('1','2')){
  Write-Host '  请输入 1、2 或 3。' -ForegroundColor Yellow
  WaitReturn
  continue
 }
 Write-Host ''
 try{
  OfficeClosed
  Write-Host '  正在处理，请稍候…' -ForegroundColor Cyan
  if($choice -eq '1'){Install}else{Restore}
 }catch{
  Write-Host ('  '+$_.Exception.Message) -ForegroundColor Yellow
 }
 WaitReturn
}


