from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as E

A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
A14 = '{http://schemas.microsoft.com/office/drawing/2010/main}'
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
M = '{http://schemas.openxmlformats.org/officeDocument/2006/math}'
def presentation(folder):
    with ZipFile(folder/'paste.docx') as doc:
        body = E.fromstring(doc.read('word/document.xml')).find(W+'body')
    with ZipFile(Path(__file__).with_name('template.pptx')) as seed, ZipFile(folder/'paste.pptx','w',ZIP_DEFLATED) as dest:
        for name in seed.namelist():
            data = seed.read(name)
            if name == 'ppt/slides/slide1.xml':
                tree = E.fromstring(data)
                box = tree.find('.//{http://schemas.openxmlformats.org/presentationml/2006/main}txBody')
                box.remove(box.find(A+'p'))
                for src in body.findall(W+'p'):
                    p = E.SubElement(box,A+'p')
                    for item in list(src):
                        if item.tag == M+'oMath':
                            E.SubElement(p,A14+'m',nsmap={'a14':A14[1:-1]}).append(item)
                        elif item.tag == W+'r':
                            for child in item:
                                if child.tag == W+'br': E.SubElement(p,A+'br')
                                if child.tag == W+'t':
                                    r=E.SubElement(p,A+'r')
                                    props=E.SubElement(r,A+'rPr')
                                    for attr in ('b','i'):
                                        if item.find(W+'rPr/'+W+attr) is not None: props.set(attr,'1')
                                    E.SubElement(r,A+'t').text=child.text
                data=E.tostring(tree,encoding='UTF-8',xml_declaration=True,standalone=True)
            dest.writestr(name,data)
