"""Recover selected KaTeX visual trees when the preceding MathML was omitted.

Only understood layouts are accepted; unknown vertical layouts fail closed.
"""
import re
from lxml import etree

def classes(node):
    return set(node.get('class', '').split())

def em(node, name):
    match = re.search(r'(?:^|;)\s*' + name + r':\s*(-?[\d.]+)em', node.get('style', ''))
    if not match:
        raise ValueError('Missing KaTeX layout metric')
    return float(match[1])

def recover(node):
    def element(tag, *children, text=None):
        out = etree.Element(tag)
        out.text = text
        out.extend(children)
        return out

    def slots(n):
        # Only the first, direct vertical list; nested fractions have their own.
        t = next(c for c in n if 'vlist-t' in classes(c))
        row = next(c for c in t if 'vlist-r' in classes(c))
        vlist = next(c for c in row if 'vlist' in classes(c))
        return list(vlist)

    def read(n):
        cls = classes(n)
        if cls & {'strut', 'pstrut', 'mspace', 'vlist-s', 'nulldelimiter'}:
            return element('mrow')
        if 'mfrac' in cls:
            rows = slots(n)
            line = [r for r in rows if any('frac-line' in classes(c) for c in r)]
            content = [r for r in rows if r not in line]
            if len(line) != 1 or len(content) != 2:
                raise ValueError('Incomplete fraction')
            content.sort(key=lambda r: em(r, 'top'))
            if not em(content[0], 'top') < em(line[0], 'top') < em(content[1], 'top'):
                raise ValueError('Ambiguous fraction')
            return element('mfrac', read(content[0]), read(content[1]))
        if cls & {'sqrt', 'vlist', 'vlist-t', 'mtable', 'accent', 'op-limits'}:
            raise ValueError('Unsupported visual math layout')
        children = []
        text = (n.text or '').replace('\u200b', '').strip()
        if text:
            leaf = element('mn' if text.isdecimal() else 'mo' if cls & {'mbin','mrel','mopen','mclose','mpunct'} else 'mi', text=text)
            if 'mathbf' in cls:
                leaf.set('mathvariant', 'bold')
            children.append(leaf)
        for c in n:
            if 'msupsub' in classes(c):
                if not children:
                    raise ValueError('Missing script base')
                scripts = {}
                for row in slots(c):
                    strut = next(x for x in row if 'pstrut' in classes(x))
                    kind = 'sub' if em(row, 'top') + em(strut, 'height') > 0 else 'sup'
                    if kind in scripts:
                        raise ValueError('Ambiguous scripts')
                    scripts[kind] = read(row)
                base = children.pop()
                if set(scripts) == {'sub','sup'}:
                    children.append(element('msubsup', base, scripts['sub'], scripts['sup']))
                elif len(scripts) == 1:
                    kind = next(iter(scripts))
                    children.append(element('m'+kind, base, scripts[kind]))
                else:
                    raise ValueError('Missing script')
            else:
                children.append(read(c))
            if (c.tail or '').strip().replace('\u200b',''):
                raise ValueError('Unexpected visual text')
        return element('mrow', *children)

    math = element('math', read(node))
    math.set('xmlns', 'http://www.w3.org/1998/Math/MathML')
    return etree.tostring(math, encoding='unicode')
