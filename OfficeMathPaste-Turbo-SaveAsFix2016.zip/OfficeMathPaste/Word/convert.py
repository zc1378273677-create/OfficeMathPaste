import base64
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from math_core import Converter
from word_output import write_docx
converter = Converter()
def process(folder):
    plain = (folder/'text').read_text('utf-8-sig')
    rich = (folder/'html').read_bytes()
    result = converter.prepare(plain,rich) if rich else None
    if not result and plain:
        result = converter.prepare(plain)
    if not result:
        return False
    write_docx(folder/'paste.docx',*result)
    pass
    return True
for line in sys.stdin.buffer:
    try:
        folder = Path(base64.b64decode(line.strip(),validate=True).decode('utf-8'))
        print('OK' if process(folder) else 'NONE',flush=True)
    except Exception:
        print('ERROR',flush=True)
