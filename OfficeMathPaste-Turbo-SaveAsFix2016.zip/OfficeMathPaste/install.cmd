@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0setup.ps1" %*
exit /b %errorlevel%
