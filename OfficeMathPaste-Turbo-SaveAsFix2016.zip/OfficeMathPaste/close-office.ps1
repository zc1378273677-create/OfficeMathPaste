﻿function SaveUntitledOfficeDocument($app, $doc, [string]$name) {
 $dialog=$null; $windows=$null; $window=$null
 try {
  # Save As targets the active document; activate this exact document first.
  if($name -eq 'PowerPoint'){
   $windows=$doc.Windows
   if($windows.Count -eq 0){throw '文档没有可见窗口，请手动打开并保存。'}
   $window=$windows.Item(1)
   $window.Activate()
  }else{$doc.Activate()}
  Write-Host "  $name：请在另存为窗口中为「$($doc.Name)」选择保存位置。" -ForegroundColor Cyan
  $dialog=$app.FileDialog(2) # msoFileDialogSaveAs; retains native overwrite prompts
  if($dialog.Show() -ne -1){return $false}
  $dialog.Execute()
  return [bool]($doc.Path -and $doc.Saved)
 } finally {
  foreach($obj in @($dialog,$window,$windows)){
   if($null -ne $obj -and [Runtime.InteropServices.Marshal]::IsComObject($obj)){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($obj)}
  }
 }
}

function SaveCloseOffice {
 $targets=@(
  @{Name='Word';Prog='Word.Application';Collection='Documents'},
  @{Name='PowerPoint';Prog='PowerPoint.Application';Collection='Presentations'},
  @{Name='Excel';Prog='Excel.Application';Collection='Workbooks'}
 )
 Write-Host '  正在保存文档；若出现 Office 提示，请在对应窗口中处理。' -ForegroundColor Cyan
 foreach($target in $targets){
  $app=$null; $items=$null
  try {
   try {$app=[Runtime.InteropServices.Marshal]::GetActiveObject($target.Prog)}
   catch {Write-Host "  $($target.Name)：未连接到运行实例，不会强制关闭。";continue}
   $items=$app.($target.Collection)
   $allSaved=$true
   for($i=1;$i -le $items.Count;$i++){
    $doc=$null
    try {
     $doc=$items.Item($i)
     if(!$doc.Path){
      if(!(SaveUntitledOfficeDocument $app $doc $target.Name)){
       Write-Host "  $($target.Name)：另存为已取消或未完成，保留文档。" -ForegroundColor Yellow
       $allSaved=$false
      }
     } elseif(!$doc.Saved){
      $doc.Save()
      if(!$doc.Saved){throw '保存未完成或已取消。'}
     }
    } catch {
     $allSaved=$false
     Write-Host "  $($target.Name)：保存失败，保留窗口。$($_.Exception.Message)" -ForegroundColor Yellow
    } finally {
     if($null -ne $doc -and [Runtime.InteropServices.Marshal]::IsComObject($doc)){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($doc)}
    }
   }
   # Check again before requesting native shutdown. Never suppress save prompts.
   for($i=1;$i -le $items.Count;$i++){
    $doc=$items.Item($i)
    try {if(!$doc.Saved -or !$doc.Path){$allSaved=$false}}
    finally {if([Runtime.InteropServices.Marshal]::IsComObject($doc)){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($doc)}}
   }
   if($allSaved){$app.Quit();Write-Host "  $($target.Name)：已保存，已请求正常退出。" -ForegroundColor Green}
   else {Write-Host "  $($target.Name)：仍有文档需要处理，已保留应用。" -ForegroundColor Yellow}
  } catch {
   Write-Host "  $($target.Name)：未能完成，请检查窗口。$($_.Exception.Message)" -ForegroundColor Yellow
  } finally {
   foreach($obj in @($items,$app)){
    if($null -ne $obj -and [Runtime.InteropServices.Marshal]::IsComObject($obj)){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($obj)}
   }
  }
 }
 if(@(Get-Process WINWORD,POWERPNT,EXCEL -ErrorAction SilentlyContinue).Count){
  Write-Host '  仍有 Office 进程运行，可能有其他实例或尚未退出。请检查窗口；不会强制结束进程。' -ForegroundColor Yellow
 }else{Write-Host '  Word、PowerPoint、Excel 均已退出。' -ForegroundColor Green}
 Write-Host '  此选项仅处理 Word、PowerPoint、Excel。' -ForegroundColor DarkGray
}
