"""Local LaTeX/MathML to Office Math. No network access at runtime."""
from __future__ import annotations
import html as html_std
import re
import uuid
from pathlib import Path
from lxml import etree, html
from latex2mathml.converter import convert

SKIP = {'pre', 'code', 'script', 'style', 'textarea'}
BLOCKS = {'p','div','section','article','blockquote','li','h1','h2','h3','h4','h5','h6'}
MATH_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'

def find_xsl():
    for base in (Path('C:/Program Files/Microsoft Office'), Path('C:/Program Files (x86)/Microsoft Office')):
        for relative in ('root/Office16/MML2OMML.XSL', 'Office16/MML2OMML.XSL'):
            path = base / relative
            if path.exists():
                return path
    raise FileNotFoundError('Office MML2OMML.XSL was not found')

def fragment(raw):
    if isinstance(raw, str):
        raw = raw.encode('utf-8')
    # CF_HTML offsets are bytes, not Unicode character offsets.
    start = re.search(br'StartFragment:(\d+)', raw[:1500])
    end = re.search(br'EndFragment:(\d+)', raw[:1500])
    if start and end and 0 <= int(start[1]) < int(end[1]) <= len(raw):
        raw = raw[int(start[1]):int(end[1])]
    else:
        start_html = re.search(br'StartHTML:(\d+)', raw[:1500])
        if start_html and 0 <= int(start_html[1]) < len(raw):
            raw = raw[int(start_html[1]):]
    return raw.rstrip(b'\0').decode('utf-8', errors='replace')

def escaped(text, index):
    n = 0
    index -= 1
    while index >= 0 and text[index] == '\\':
        n += 1
        index -= 1
    return n % 2 == 1

def formulas(text):
    """Yield complete delimited ranges; leave malformed/currency text alone."""
    protected = bytearray(len(text))
    for match in re.finditer(r'```[\s\S]*?```|~~~[\s\S]*?~~~|`+[^`\n]*`+|https?://[^\s<>]+', text):
        protected[match.start():match.end()] = b'\1' * (match.end()-match.start())
    i = 0
    while i < len(text):
        if protected[i] or escaped(text, i):
            i += 1
            continue
        opener = next((s for s in ('\\[', '\\(', '$$', '$') if text.startswith(s, i)), None)
        if not opener:
            i += 1
            continue
        if opener.startswith('$') and (text[i-1:i] == '$' or text[i+len(opener):i+len(opener)+1] == '$'):
            i += len(opener)
            continue
        if opener == '$' and (i+1 == len(text) or text[i+1].isspace()):
            i += 1
            continue
        closer = {'\\[':'\\]', '\\(':'\\)', '$$':'$$', '$':'$'}[opener]
        display = opener in ('\\[', '$$')
        j = i + len(opener)
        found = False
        while j < len(text):
            if protected[j] or text[j] == '\0' or (not display and text[j] == '\n'):
                break
            if not escaped(text, j) and text.startswith(closer, j):
                if closer.startswith('$') and (text[j-1:j] == '$' or text[j+len(closer):j+len(closer)+1] == '$'):
                    j += len(closer)
                    continue
                body = text[i+len(opener):j]
                if body.strip() and (opener != '$' or not text[j-1].isspace()):
                    # Avoid interpreting two currency amounts as one equation.
                    if opener != '$' or not re.fullmatch(r'[\d.,\s]+', body):
                        yield i, j+len(closer), body.strip(), display
                i = j + len(closer)
                found = True
                break
            if not escaped(text,j) and opener.startswith('\\') and text.startswith(opener,j):
                break
            j += 1
        if not found:
            i += len(opener)

class Converter:
    def __init__(self):
        parser = etree.XMLParser(resolve_entities=False, no_network=True)
        self.transform = etree.XSLT(etree.parse(str(find_xsl()), parser))
        self.parser = parser

    def mathml(self, source):
        root = etree.fromstring(source.encode('utf-8'), self.parser)
        result = self.transform(root)
        output = result.getroot()
        if output is not None and etree.QName(output).localname == 'oMathPara':
            output = output.find('{'+MATH_NS+'}oMath')
        if output is None or etree.QName(output).localname != 'oMath':
            raise ValueError('MathML did not produce Office Math')
        return etree.tostring(output, encoding='unicode')

    def latex(self, tex, display=False):
        # latex2mathml does not parse aligned as a table. Its raw '&'
        # output is invalid XML. An array retains the equation rows and columns.
        tex = re.sub(r'\\begin\{aligned\}(?:\s*\[[tbc]\])?',
                     lambda match: r'\begin{array}{rl}', tex)
        tex = tex.replace(r'\end{aligned}', r'\end{array}')
        source = convert(tex, display='block' if display else 'inline')
        # latex2mathml emits an merror for some unsupported commands.
        if '<merror' in source:
            raise ValueError('Unsupported LaTeX')
        return self.mathml(source)

    def prepare(self, plain='', rich=None):
        """Return sanitized HTML with placeholders and native OMML replacements."""
        source = fragment(rich) if rich else '<div>' + html_std.escape(plain).replace('\r\n','\n').replace('\n','<br>') + '</div>'
        root = html.fragment_fromstring(source, create_parent='div')
        replacements = []
        nonce = 'OfficeMathPaste' + uuid.uuid4().hex

        def protect(omml, display):
            token = nonce + 'N' + str(len(replacements)) + 'End'
            replacements.append((token, omml, display))
            return token

        # Never import active content or remote document links into hidden Word.
        for node in list(root.iter()):
            if not isinstance(node.tag, str):
                continue
            tag = etree.QName(node).localname.lower()
            if tag in {'script','style','iframe','object','embed','link','meta','base'}:
                node.drop_tree()
                continue
            for attr in list(node.attrib):
                if attr.lower().startswith('on') or attr.lower() in ('src','srcset','background'):
                    del node.attrib[attr]

        for annotation in list(root.xpath('.//*[local-name()="annotation"]')):
            if annotation.get('encoding','').strip().lower() != 'application/x-tex':
                continue
            ancestors = list(annotation.iterancestors())
            if any(etree.QName(n).localname.lower() in SKIP for n in ancestors):
                continue
            container = next((n for n in ancestors if 'katex-display' in n.get('class','').split()), None)
            if container is None:
                container = next((n for n in ancestors if 'katex' in n.get('class','').split()), None)
            if container is None:
                container = next((n for n in ancestors if etree.QName(n).localname.lower() in {'math','mjx-container'}), None)
            if container is None or container.getparent() is None:
                continue
            display = ('katex-display' in container.get('class','').split() or container.get('display') in ('block','true'))
            try:
                token = protect(self.latex(''.join(annotation.itertext()).strip(), display), display)
            except Exception:
                continue
            marker = etree.Element('span')
            marker.text, marker.tail = token, container.tail
            container.getparent().replace(container, marker)

        # MathML without a TeX annotation can also be converted exactly.
        for node in list(root.xpath('.//*[local-name()="math"]')):
            if node.getparent() is None or any(etree.QName(a).localname.lower() in SKIP for a in node.iterancestors()):
                continue
            try:
                markup = etree.tostring(node, encoding='unicode', with_tail=False)
                if 'xmlns=' not in markup:
                    markup = markup.replace('<math', '<math xmlns="http://www.w3.org/1998/Math/MathML"', 1)
                token = protect(self.mathml(markup), node.get('display') == 'block')
            except Exception:
                continue
            marker = etree.Element('span')
            marker.text, marker.tail = token, node.tail
            node.getparent().replace(node, marker)

        # Flatten only text content; formulas may cross bold/span boundaries.
        segments, pieces = [], []
        length = 0
        def append(value, node=None, attr=None):
            nonlocal length
            if value:
                if node is not None:
                    segments.append((node, attr, length, length+len(value)))
                pieces.append(value)
                length += len(value)
        def walk(node):
            tag = etree.QName(node).localname.lower() if isinstance(node.tag,str) else ''
            if tag in SKIP or tag in {'math','mjx-container'}:
                append('\0')
                return
            barrier = tag in {'td','th','tr','table','a'}
            block = tag in BLOCKS
            if barrier: append('\0')
            elif block or tag == 'br': append('\n')
            append(node.text, node, 'text')
            for child in node:
                walk(child)
                append(child.tail, child, 'tail')
            if barrier: append('\0')
            elif block: append('\n')
        walk(root)
        text = ''.join(pieces)
        for start, end, tex, display in reversed(list(formulas(text))):
            try:
                token = protect(self.latex(tex, display), display)
            except Exception:
                continue
            affected = [(n,a,f,t) for n,a,f,t in segments if t > start and f < end]
            for index, (node, attr, begin, finish) in enumerate(affected):
                old = getattr(node, attr) or ''
                left, right = max(start,begin)-begin, min(end,finish)-begin
                setattr(node, attr, old[:left] + (token if index == 0 else '') + old[right:])
        if not replacements:
            return None
        body = etree.tostring(root, encoding='unicode', method='html')
        return '<!doctype html><html><head><meta charset="utf-8"></head><body>' + body + '</body></html>', replacements
